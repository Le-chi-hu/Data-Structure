#include <iostream>
#include <ctime>
#include <fstream>
#include <windows.h>
using namespace std;


void Add(int** a, int** b, int** c, int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            c[i][j] = a[i][j] + b[i][j];
        }
    }
}


void PrintSystemInfo() {
    SYSTEM_INFO siSysInfo;
    GetSystemInfo(&siSysInfo);

    cout << "�q���w���T:" << endl;
    cout << " OEM ID: " << siSysInfo.dwOemId << endl;
    cout << " �B�z���ƶq: " << siSysInfo.dwNumberOfProcessors << endl;
    cout << " �����j�p: " << siSysInfo.dwPageSize << endl;
    cout << " �B�z������: " << siSysInfo.dwProcessorType << endl;

    
   
    char computerName[256];
    DWORD size = sizeof(computerName);
    if (GetComputerNameA(computerName, &size)) {
        cout << " �p����W��: " << computerName << endl;
    } else {
        cerr << " �L�k����p����W��!" << endl;
    }
}

int main() {

    PrintSystemInfo();

    ofstream outfile("matrix_addition_time.csv");
    if (!outfile.is_open()) {
        cerr << "�L�k���}���!" << endl;
        return 1;
    }

    outfile << "Matrix Size (n),Time (seconds)\n";
    cout << "�x�}�j�p (n), �p��ɶ� (��)" << endl;

    for (int n = 100; n <= 5000; n += 100) {
        int m = n;

        int** a = new int* [m];
        int** b = new int* [m];
        int** c = new int* [m];
        for (int i = 0; i < m; i++) {
            a[i] = new int[n];
            b[i] = new int[n];
            c[i] = new int[n];
        }

     
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = 1;
                b[i][j] = 1;
            }
        }

      
        clock_t start_time = clock();
        Add(a, b, c, m, n);
        clock_t end_time = clock();
        float total_time = static_cast<float>(end_time - start_time) / CLOCKS_PER_SEC;

      
        outfile << n << "," << total_time << "\n";
        cout << n << ", " << total_time << " ��" << endl;

   
        for (int i = 0; i < m; i++) {
            delete[] a[i];
            delete[] b[i];
            delete[] c[i];
        }
        delete[] a;
        delete[] b;
        delete[] c;
    }

    outfile.close(); 
    return 0;
}

