import matplotlib.pyplot as plt
import pandas as pd


data = pd.read_csv("matrix_addition_time.csv")


matrix_size = data['Matrix Size (n)']
time_taken = data['Time (seconds)']


plt.figure(figsize=(10, 6))
plt.plot(matrix_size, time_taken, marker='o', color='b')


plt.title('Matrix Addition Time vs Matrix Size')
plt.xlabel('Matrix Size (n)')
plt.ylabel('Time (seconds)')


plt.grid(True)
plt.show()
