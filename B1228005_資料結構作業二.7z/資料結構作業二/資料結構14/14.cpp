#include <iostream>
#include <ctime>
#include <fstream> 
using namespace std;


void Multiply(int **a, int **b, int **c, int m, int n, int p) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < p; j++) {
            c[i][j] = 0;  
            for (int k = 0; k < n; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}

int main() {
  
    ofstream outfile("matrix_multiplication_time.txt");
    if (!outfile.is_open()) {
        cerr << "�L�k���}���" << endl;
        return 1;
    }

 
    outfile << "Matrix Size (n), Time (seconds)\n";  
    cout << "�x�}�j�p (n), �p��ɶ� (��)" << endl;

    
    for (int n = 100; n <= 2000; n += 100) {
        int m = n, p = n;  

     
        int **a = new int*[m];
        int **b = new int*[n];
        int **c = new int*[m];
        for (int i = 0; i < m; i++) {
            a[i] = new int[n];
            c[i] = new int[p];
        }
        for (int i = 0; i < n; i++) {
            b[i] = new int[p];
        }

   
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = 1;  
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                b[i][j] = 1; 
            }
        }

     
        clock_t start_time = clock();
        Multiply(a, b, c, m, n, p);
        clock_t end_time = clock();
        float total_time = (float)(end_time - start_time) / CLOCKS_PER_SEC;

      
        outfile << n << ", " << total_time << "\n";
        cout << "�x�}�j�p n = " << n << "�A�p��ɶ�: " << total_time << " ��" << endl;

      
        for (int i = 0; i < m; i++) {
            delete[] a[i];
            delete[] c[i];
        }
        for (int i = 0; i < n; i++) {
            delete[] b[i];
        }
        delete[] a;
        delete[] b;
        delete[] c;
    }

    outfile.close();  
    return 0;
}

