import matplotlib.pyplot as plt


matrix_sizes = []
times = []

with open("matrix_multiplication_time.txt", "r") as file:

    next(file)
    

    for line in file:
        size, time = line.split(", ")
        matrix_sizes.append(int(size))
        times.append(float(time))


plt.figure(figsize=(10, 6))
plt.plot(matrix_sizes, times, marker='o', color='r')


plt.title('Matrix Multiplication Time vs Matrix Size')
plt.xlabel('Matrix Size (n)')
plt.ylabel('Time (seconds)')


plt.grid(True)
plt.show()
